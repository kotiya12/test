import React from 'react'

const NotFound = () => {
    return (
        <div>
            404 ERROR
        </div>
    )
}

export default NotFound
