import React from 'react';
import{Redirect} from "react-router-dom"
 



function Home({authorized}){

    if (!authorized){
        return<Redirect to ="/login" />;
    }
    return (
        <div>
        you are logged in
        </div>

    );
}

export default Home
